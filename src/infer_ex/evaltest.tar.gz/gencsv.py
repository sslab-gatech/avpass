import sys
import os
import csv
import json

sys.path.append('./modules')
from conf import *
from common import *

ARRAY_LEN = len(INFERRING_LIST)
SHA1SUM = "sha1sum.txt"


def load_json_file(filename):
	with open(filename) as json_data:
		d = json.load(json_data)
		json_data.close()
	return d

def find_values(id, json_repr):
	results = []

	def _decode_dict(a_dict):
		try: results.append(a_dict[id])
		except KeyError: pass
		return a_dict

	json.loads(json_repr, object_hook=_decode_dict)  # return value ignored
	return results

def zerolist(n):
    listofzeros = [0] * n
    return listofzeros

def load_file_list(dirname, extension):
    """Get all files end with extension in an apk project directory."""
    extension_path = []
    for root, dirs, files in os.walk(dirname):
        for filename in files:
            if filename.endswith(extension):
                extension_path.append(root + "/" + filename)
                continue
    return extension_path

def load_sha1_table(filename):
	sha_to_file = {}
	file_to_sha = {}

	with open(filename) as f:
		for line in f:
			(key, val) = line.split()
			sha_to_file[key] = val
			file_to_sha[val] = key

	return sha_to_file, file_to_sha

def ret_filename_from_path(path):
	numdir = len(path.split('/'))
	lastword = path.split('/')[numdir-1].split('_')[1].split('.json')[0]
	return lastword

def file_to_combination_list(filename):
	# return
	#print filename
	retlist = zerolist(ARRAY_LEN)
	if '_' not in filename:
		return retlist

	number = filename.split('_')[1].split('.')[0]

	if number is not "":
		for char in number:
			retlist[int(char)] = 1
	return retlist

def ret_boolean(inp):
	#print inp
	if inp is False:
		return 0
	elif inp is True:
		return 1

def ret_family_names(sha1file):
	out = []
	family = ""
	sha1line = open(sha1file, 'r').readlines()
	for line in sha1line:
		if '  ' in line:
			filename = line.split('  ')[1]
			if '_' in line:
				family = filename.split('_')[0]

		if family not in out:
			out.append(family)
	return out

if __name__ == "__main__":
	jsonlist = load_file_list("./", '.json')

	sha_to_file, file_to_sha = load_sha1_table(SHA1SUM)
	print ret_family_names

	for jsonname in jsonlist:
		shaname = ret_filename_from_path(jsonname)
		apkname = sha_to_file[shaname]
		jsonobj = load_json_file(jsonname)

		combination_list = file_to_combination_list(apkname)
		#print jsonobj['scans'].keys()
		
		for key in jsonobj['scans'].keys():
			result = ret_boolean(jsonobj['scans'][key]['detected'])
			combination_result = combination_list + [result]
			#print combination_result
			with open(key+".csv", 'a') as myfile:
				wr = csv.writer(myfile)  #, quoting=csv.QUOTE_ALL)
				wr.writerow(combination_result)
				myfile.close()
